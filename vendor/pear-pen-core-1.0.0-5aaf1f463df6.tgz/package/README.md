# Pear Pen Core

Desktop and mobile use the same signing worker. Construct `PearPenCore` with the application version, upgrade link and name. Desktop can also supply its data directory and installed app path. Mobile supplies the Bare worklet bundle.

```js
const PearPenCore = require('pear-pen-core')
const pen = new PearPenCore({ name: 'Pear Pen', dir, version, upgrade })
pen.on('data', (frame) => receive(JSON.parse(frame.toString())))
pen.write(JSON.stringify({ id: 1, method: 'state.get' }))
```

Run `npm ci` and `npm test` in this repository. Run `npm run schema` after editing the HyperDB schema and include the generated files in the change.

Run `npm run pack:apps` to pack the worker once and update the adjacent desktop and mobile archives and lockfiles. For other checkout names, pass both paths with `npm run pack:apps -- /path/to/desktop /path/to/mobile`. Each app can then build from its own checkout using `npm ci`. Rebuild the mobile worklet with `npm run bundle:bare` after updating the package.


## Private rooms

Create a room once from its multisig configuration. Each additional signer joins with a single-use invite while the inviting device is online. Invitations expire after ten minutes. The joining signer unlocks their key locally and signs a challenge bound to the invite and a temporary Noise key. The inviter verifies the signer against the configuration before delivering the room secret to that Noise key. The receiving device independently checks the configuration and inviter. Later edits to the configuration sync as signed room activity. Every device checks that the edited configuration still produces the same drive key.

Each room has a random secret. Activity connections authenticate a signer-certified device on every Noise session before exchanging history. The public drive still replicates on its own discovery key. Earlier pens retain local signing and review. After moving a pen into a private room, its earlier history stays on that device.

The local HyperDB in `rooms.db` holds room membership and private activity separately from the replicated Corestore. Invitations and temporary admission keys live in memory. A backup of the device’s application data can include reusable room and device credentials.
