interface Worker {
  on(event: string, listener: (...args: any[]) => void): this
  once(event: string, listener: (...args: any[]) => void): this
  destroy(error?: Error): void
}

declare class PearPenCore {
  constructor(options: {
    bundle?: string
    updates?: boolean
    version?: string
    upgrade?: string
    name?: string
    dir?: string
    app?: string
  })
  readonly worker: Worker
  on(event: 'data', listener: (data: Uint8Array) => void): this
  on(event: 'error', listener: (error: Error) => void): this
  on(event: 'close', listener: () => void): this
  write(data: string | Uint8Array): boolean
  destroy(error?: Error): void
}

export = PearPenCore
