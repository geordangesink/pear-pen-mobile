const Hyperschema = require('hyperschema')
const HyperDB = require('hyperdb/builder')

const schema = Hyperschema.from('./spec/schema')
const pen = schema.namespace('pen')
pen.register({
  name: 'rooms',
  fields: [
    { name: 'drive', type: 'string', required: true },
    { name: 'roomKey', type: 'string', required: true },
    { name: 'config', type: 'string', required: true }
  ]
})
pen.register({
  name: 'events',
  fields: [
    { name: 'room', type: 'string', required: true },
    { name: 'id', type: 'string', required: true },
    { name: 'event', type: 'json', required: true }
  ]
})
Hyperschema.toDisk(schema)

const db = HyperDB.from('./spec/schema', './spec/db')
const collections = db.namespace('pen').collections
collections.register({ name: 'rooms', schema: '@pen/rooms', key: ['drive'] })
collections.register({
  name: 'events',
  schema: '@pen/events',
  key: ['room', 'id']
})
HyperDB.toDisk(db)
