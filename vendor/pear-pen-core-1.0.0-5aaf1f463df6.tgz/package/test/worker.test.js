const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const { on, once } = require('node:events')
const PearPenCore = require('../client')

function open(dir) {
  const pen = new PearPenCore({ dir, updates: false })
  const exited = once(pen.worker, 'exit')
  let serial = 0
  return {
    async call(method, params) {
      const id = ++serial
      const frames = on(pen, 'data', { signal: AbortSignal.timeout(10000) })
      try {
        pen.write(JSON.stringify({ id, method, params }))
        for await (const [frame] of frames) {
          const message = JSON.parse(frame.toString())
          if (message.type === 'error') throw new Error(message.error.message)
          if (message.id !== id) continue
          if (message.error) throw new Error(message.error.message)
          return message.result
        }
      } finally {
        await frames.return()
      }
    },
    async close() {
      pen.worker.kill()
      await exited
    }
  }
}

test('the Bare worker creates and restores a private room through app IPC', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pear-pen-worker-'))
  let worker = open(dir)
  t.after(async () => {
    await worker?.close()
    fs.rmSync(dir, { recursive: true, force: true })
  })
  const password = 'disposable-worker-test'
  const { profile } = await worker.call('profile.import', {
    name: 'Test',
    password
  })
  const config = {
    multisig: {
      namespace: 'worker-test',
      quorum: 1,
      publicKeys: [profile.publicKey]
    }
  }
  const created = await worker.call('pen.create', {
    name: 'Test room',
    config: JSON.stringify(config),
    password
  })
  assert.equal(created.pens[0].privateRoom, true)
  await worker.close()
  worker = open(dir)
  const restored = await worker.call('state.get')
  assert.deepEqual(restored.pens[0], created.pens[0])
})
