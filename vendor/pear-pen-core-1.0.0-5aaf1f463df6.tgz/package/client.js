const FramedStream = require('framed-stream')
const run = require('./lib/run')

module.exports = class PearPenCore extends FramedStream {
  constructor({ bundle, updates = true, ...options } = {}) {
    const worker = run([JSON.stringify({ ...options, updates })], bundle)
    super(worker)
    this.worker = worker
  }
}
