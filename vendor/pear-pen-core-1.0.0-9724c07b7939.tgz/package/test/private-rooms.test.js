const test = require('node:test')
const assert = require('node:assert/strict')
const os = require('node:os')
const path = require('node:path')
const fs = require('node:fs')
const Hyperswarm = require('hyperswarm')
const makeTestnet = require('hyperdht/testnet')
const Hyperdrive = require('hyperdrive')
const crypto = require('hypercore-crypto')
const z32 = require('z32')
const Engine = require('../index')
const auth = require('../lib/room-auth')
const keys = require('../lib/keys')
const { parseConfiguration } = require('../lib/configuration')

async function until(predicate) {
  const deadline = Date.now() + 15000
  while (!predicate()) {
    if (Date.now() >= deadline)
      throw new Error('Timed out waiting for room synchronization')
    await new Promise((resolve) => setTimeout(resolve, 20))
  }
}

test('private room credentials authenticate configured devices and bind both directions of one Noise session', () => {
  const member = keys.importIdentity({
    secretKey: z32.encode(crypto.keyPair().secretKey)
  })
  const stranger = keys.importIdentity({
    secretKey: z32.encode(crypto.keyPair().secretKey)
  })
  const { manifest, multisigKey } = parseConfiguration(
    JSON.stringify({
      multisig: {
        namespace: 'room-test',
        publicKeys: [member.publicKey],
        quorum: 1
      }
    })
  )
  const room = auth.membership(z32.encode(crypto.randomBytes(32)), multisigKey)
  const separate = auth.membership(
    z32.encode(crypto.randomBytes(32)),
    multisigKey
  )
  const publicKey = crypto.randomBytes(32)
  const remotePublicKey = crypto.randomBytes(32)
  const handshakeHash = crypto.randomBytes(32)
  const left = { publicKey, remotePublicKey, handshakeHash }
  const right = {
    publicKey: remotePublicKey,
    remotePublicKey: publicKey,
    handshakeHash
  }
  const hello = auth.hello(member, room, left)
  assert(auth.accepts(manifest, room, right, hello))
  assert(!auth.accepts(manifest, room, left, hello))
  assert(
    !auth.accepts(
      manifest,
      room,
      { ...right, handshakeHash: crypto.randomBytes(32) },
      hello
    )
  )
  assert(!auth.accepts(manifest, separate, right, hello))
  assert(!auth.accepts(manifest, room, right, auth.hello(stranger, room, left)))
})

test(
  'create, admit, sync and reopen a private room on an isolated swarm',
  { timeout: 60000 },
  async (t) => {
    const net = await makeTestnet(3)
    const base = fs.mkdtempSync(path.join(os.tmpdir(), 'pear-pen-private-'))
    const clients = new Map()
    async function open(name) {
      const swarm = new Hyperswarm({
        dht: net.createNode({ firewalled: false })
      })
      const app = new Engine({
        swarm,
        dir: path.join(base, name),
        timeout: 3000
      })
      clients.set(name, { app, swarm })
      await app.ready()
      return app
    }
    async function close(name) {
      const { app, swarm } = clients.get(name)
      await app.close()
      await swarm.destroy()
      clients.delete(name)
    }
    t.after(async () => {
      await Promise.all([...clients.keys()].map(close))
      await net.destroy()
      fs.rmSync(base, { recursive: true, force: true })
    })
    const alice = await open('alice')
    let bob = await open('bob')
    const outsider = await open('outsider')
    const password = 'throwaway password'
    for (const app of [alice, bob, outsider])
      await app.command('profile.import', { password })
    const config = JSON.stringify({
      multisig: {
        namespace: 'private-room-test',
        publicKeys: [alice.identity.publicKey, bob.identity.publicKey],
        quorum: 2
      }
    })
    const { multisigKey: penId } = parseConfiguration(config)
    await assert.rejects(
      alice.command('pen.create', { config, password: 'wrong' }),
      /password/
    )
    await assert.rejects(
      outsider.command('pen.create', { config, password }),
      /not a signer/
    )
    assert.equal(outsider.snapshot().pens.length, 0)
    await alice.command('pen.create', {
      config,
      password,
      name: 'Private room'
    })
    await outsider.command('pen.add', { multisigKey: penId })
    await bob.command('pen.add', { config, name: 'Bob’s saved pen' })
    const legacySource = new Hyperdrive(bob.store.namespace('legacy-source'))
    await legacySource.ready()
    await legacySource.put('/before.txt', Buffer.from('older local activity'))
    const oldLink = `pear://${legacySource.core.fork}.${legacySource.core.length}.${z32.encode(legacySource.key)}`
    await legacySource.close()
    await bob.command('request.create', { penId, srcKey: oldLink })
    const legacyRequest = bob.snapshot().pens[0].request
    const { invite } = await alice.command('pen.invite', { penId })
    await assert.rejects(
      bob.command('pen.join', {
        invite,
        password,
        penId: z32.encode(crypto.randomBytes(32))
      }),
      /does not match/
    )
    await assert.rejects(
      alice.command('pen.join', { invite, password }),
      /already has a private room/
    )
    await assert.rejects(
      outsider.command('pen.join', { invite, password, penId }),
      /Only a signer/
    )
    await bob.command('pen.join', { invite, password, penId })
    assert.equal(bob.snapshot().pens[0].request, null)
    assert.equal(bob.snapshot().pens[0].name, 'Bob’s saved pen')
    assert(
      bob
        .snapshot()
        .pens[0].activity.some(
          (item) => item.localOnly && item.id === legacyRequest.id
        )
    )
    await until(
      () =>
        alice.snapshot().pens[0].peers === 1 &&
        bob.snapshot().pens[0].peers === 1
    )
    assert.deepEqual(await bob.command('pen.configuration', { penId }), {
      config
    })
    const revisedConfig = JSON.stringify({
      ...JSON.parse(config),
      description: 'Updated instructions'
    })
    await alice.command('pen.configure', {
      penId,
      config: revisedConfig,
      name: 'Local name'
    })
    await until(() => bob.rooms.get(penId).pen.config === revisedConfig)
    assert.equal(bob.snapshot().pens[0].name, 'Bob’s saved pen')
    assert(
      !outsider
        .snapshot()
        .pens[0].activity.some((entry) => entry.type === 'configuration')
    )
    const src = new Hyperdrive(alice.store.namespace('room-test-source'))
    await src.ready()
    await src.put('/index.js', Buffer.from('test'))
    const srcKey = `pear://${src.core.fork}.${src.core.length}.${z32.encode(src.key)}`
    await src.close()
    await alice.command('request.create', { penId, srcKey })
    await until(() => bob.snapshot().pens[0].request)
    const request = bob.snapshot().pens[0].request
    await bob.command('request.sign', {
      penId,
      requestId: request.id,
      password
    })
    await until(() => alice.snapshot().pens[0].request?.signatures.length === 1)
    assert.equal(outsider.snapshot().pens[0].peers, 0)
    assert.equal(outsider.snapshot().pens[0].request, null)
    const room = bob.rooms.get(penId)
    const roomKey = z32.encode(room.secret)
    assert(!JSON.stringify(bob.snapshot()).includes(roomKey))
    assert(
      !fs
        .readFileSync(path.join(bob.dir, 'state.json'), 'utf8')
        .includes(roomKey)
    )
    const legacyFile = path.join(bob.dir, `events-${penId}.json`)
    assert(!fs.readFileSync(legacyFile, 'utf8').includes(request.id))
    assert(
      !alice
        .snapshot()
        .pens[0].activity.some((item) => item.id === legacyRequest.id)
    )
    await close('bob')
    bob = await open('bob')
    assert.deepEqual(await bob.command('pen.configuration', { penId }), {
      config: revisedConfig
    })
    assert.equal(bob.snapshot().pens[0].request.id, request.id)
    assert(
      bob
        .snapshot()
        .pens[0].activity.some(
          (item) => item.localOnly && item.id === legacyRequest.id
        )
    )
    await until(() => bob.snapshot().pens[0].peers === 1)
    await bob.command('pen.remove', { penId })
    assert(!fs.existsSync(legacyFile))
    assert.equal(await bob.db.get('@pen/rooms', { drive: penId }), null)
    assert.equal((await bob._storedEvents(room.scope).toArray()).length, 0)
    await bob.command('pen.create', { config, password })
    assert.notEqual(bob.rooms.get(penId).scope, room.scope)
    assert.equal(bob.snapshot().pens[0].request, null)
    await assert.rejects(
      bob._receive(bob.rooms.get(penId), alice.rooms.get(penId).events[0]),
      /different room/
    )
  }
)
