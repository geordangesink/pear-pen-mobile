const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const { once } = require('node:events')
const test = require('node:test')
const Corestore = require('corestore')
const Hyperdrive = require('hyperdrive')
const blockMap = require('hyperblobs/lib/block-map')
const {
  normalizePackageVersion,
  readPackageVersion
} = require('../lib/package-version')

async function fixture(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pear-pen-version-'))
  const store = new Corestore(dir)
  const drive = new Hyperdrive(store)
  await drive.ready()
  t.after(async () => {
    await drive.close()
    await store.close()
    fs.rmSync(dir, { recursive: true, force: true })
  })
  return drive
}

for (const dedup of [false, true]) {
  test(`reads the pinned /package.json across later appends (dedup ${dedup})`, async (t) => {
    const drive = await fixture(t)
    const stream = drive.createWriteStream('/package.json', { dedup })
    const written = once(stream, 'close')
    stream.end(Buffer.from('{"version":"1.0.0-beta.1+ci.7"}'))
    await written
    const length = drive.blobs.core.length
    const checkout = drive.checkout(drive.version)
    t.after(() => checkout.close())
    await drive.put('/package.json', Buffer.from('{"version":"2.0.0"}'))
    assert.equal(
      await readPackageVersion(checkout, length, { wait: false }),
      '1.0.0-beta.1+ci.7'
    )
    assert.equal(
      await readPackageVersion(checkout, length - 1, { wait: false }),
      undefined
    )
  })
}

test('omits absent or invalid package metadata and ignores nested packages', async (t) => {
  const drive = await fixture(t)
  await drive.put('/sub/package.json', Buffer.from('{"version":"3.0.0"}'))
  async function read() {
    const checkout = drive.checkout(drive.version)
    try {
      return await readPackageVersion(checkout, drive.blobs.core.length, {
        wait: false
      })
    } finally {
      await checkout.close()
    }
  }
  assert.equal(await read(), undefined)
  for (const text of [
    '{',
    'null',
    '{}',
    '{"version":3}',
    JSON.stringify({ version: '1.0.0', padding: 'x'.repeat(256 * 1024) })
  ]) {
    await drive.put('/package.json', Buffer.from(text))
    assert.equal(await read(), undefined)
  }
  assert.equal(normalizePackageVersion('1.2.3\nrelease'), undefined)
})

test('a missing map or a map pointing outside the signed length never fetches unrelated blocks', async (t) => {
  const drive = await fixture(t)
  const blocks = await blockMap.encode({
    blocks: [{ index: 1, byteLength: 19 }]
  })
  const blob = await drive.blobs.put(blocks[0])
  await drive.putEntry('/package.json', { blob: { ...blob, blockMap: true } })
  const checkout = drive.checkout(drive.version)
  t.after(() => checkout.close())
  const reads = []
  const core = {
    async get(index, options) {
      reads.push(index)
      assert.equal(options.wait, false)
      return drive.blobs.core.get(index, options)
    }
  }
  assert.equal(
    await readPackageVersion(checkout, 1, { wait: false }, core),
    undefined
  )
  assert.deepEqual(reads, [0])
  await drive.blobs.core.clear(0, 1)
  assert.equal(
    await readPackageVersion(checkout, 1, { wait: false }, core),
    undefined
  )
  assert.deepEqual(reads, [0, 0])
})
