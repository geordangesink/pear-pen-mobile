const test = require('node:test')
const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const Hyperswarm = require('hyperswarm')
const makeTestnet = require('hyperdht/testnet')
const crypto = require('hypercore-crypto')
const z32 = require('z32')
const Admission = require('../lib/admission')
const { parseConfiguration } = require('../lib/configuration')
const { importIdentity } = require('../lib/keys')

const password = 'test-only password'

async function room(t) {
  const net = await makeTestnet(3)
  const swarms = [0, 1].map(
    () => new Hyperswarm({ dht: net.createNode({ firewalled: false }) })
  )
  const now = [Date.now(), Date.now()]
  const [host, guest] = swarms.map(
    (swarm, i) =>
      new Admission(swarm, { now: () => now[i], poll: 100, timeout: 10000 })
  )
  t.after(async () => {
    await Promise.all([host.close(), guest.close()])
    await Promise.all(swarms.map((swarm) => swarm.destroy()))
    await net.destroy()
  })
  const issuer = importIdentity({ password })
  const signer = importIdentity({ password })
  const config = JSON.stringify({
    multisig: {
      namespace: 'test',
      quorum: 2,
      publicKeys: [issuer.publicKey, signer.publicKey]
    }
  })
  const pen = {
    multisigKey: parseConfiguration(config).multisigKey,
    config,
    roomKey: z32.encode(crypto.randomBytes(32))
  }
  return {
    host,
    guest,
    issuer,
    signer,
    pen,
    advance: (side, ms) => (now[side] += ms)
  }
}

test('only a password-unlocked manifest signer receives the private room from a one-use invite', async (t) => {
  const { host, guest, issuer, signer, pen } = await room(t)
  const outsider = importIdentity({ password })
  await assert.rejects(host.invite(pen, outsider), /Only a signer/)
  const { invite } = await host.invite(pen, issuer)
  await assert.rejects(
    guest.join(invite, signer, 'incorrect'),
    /Incorrect private key password/
  )
  await assert.rejects(guest.join(invite, outsider, password), /Only a signer/)
  assert.deepEqual(await guest.join(invite, signer, password), pen)
  guest.timeout = 300
  await assert.rejects(
    guest.join(invite, signer, password),
    /unavailable|used|expired|closed/i
  )
})

test('invites pin their pen and issuer, expire after ten minutes, and can be revoked per room', async (t) => {
  const { host, guest, issuer, signer, pen, advance } = await room(t)
  const other = { ...pen, roomKey: z32.encode(crypto.randomBytes(32)) }
  const first = await host.invite(pen, issuer)
  const second = await host.invite(other, issuer)
  const prefix = 'pear-pen://invite/'
  const bytes = z32.decode(first.invite.slice(prefix.length))
  bytes[0] ^= 1
  await assert.rejects(
    guest.join(prefix + z32.encode(bytes), signer, password),
    /valid Pear Pen invite/
  )
  await host.revoke(pen.roomKey)
  guest.timeout = 300
  await assert.rejects(
    guest.join(first.invite, signer, password),
    /unavailable/i
  )
  guest.timeout = 10000
  assert.deepEqual(await guest.join(second.invite, signer, password), other)
  const third = await host.invite(pen, issuer)
  advance(0, 10 * 60 * 1000)
  await assert.rejects(guest.join(third.invite, signer, password), /expired/)
  advance(1, 10 * 60 * 1000)
  await assert.rejects(guest.join(third.invite, signer, password), /expired/)
})

test('a signer can retry an unused invite after its grant connection fails', async (t) => {
  const { host, guest, issuer, signer, pen } = await room(t)
  const { invite } = await host.invite(pen, issuer)
  const grantKey = [...host.invites][0].keyPair.publicKey
  const connect = guest.dht.connect.bind(guest.dht)
  guest.dht.connect = (key, options) => {
    if (!grantKey.equals(key)) return connect(key, options)
    const socket = new EventEmitter()
    socket.destroy = () => {}
    queueMicrotask(() =>
      socket.emit('error', new Error('Interrupted connection'))
    )
    return socket
  }
  await assert.rejects(
    guest.join(invite, signer, password),
    /Interrupted connection/
  )
  guest.dht.connect = connect
  const secondDevice = importIdentity({ secretKey: signer.secretKey, password })
  await assert.rejects(
    guest.join(invite, issuer, password),
    /already been used/
  )
  await assert.rejects(
    guest.join(invite, secondDevice, password),
    /already been used/
  )
  assert.deepEqual(await guest.join(invite, signer, password), pen)
})

test(
  'an unreachable inviter times out or cancels even while blind-pairing is draining',
  { timeout: 5000 },
  async (t) => {
    const { host, guest, issuer, signer, pen } = await room(t)
    const { invite } = await host.invite(pen, issuer)
    let closed = 0
    guest.pairing.addCandidate = () => ({
      request: new EventEmitter(),
      close() {
        closed++
        return new Promise(() => {})
      }
    })
    guest.timeout = 50
    await assert.rejects(guest.join(invite, signer, password), /unavailable/i)
    const join = guest.join(invite, signer, password)
    guest.cancelJoins()
    await assert.rejects(join, /cancelled/i)
    assert.equal(closed, 2)
    assert.equal(guest.joins.size, 0)
  }
)
